<div id="pageloader">
        <div class="loader-item"> <img src="../assets/img/other/puff.svg" alt="page loader">
        </div>
    </div>